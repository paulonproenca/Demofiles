# API Management Create GraphQL API

APIM create a GraphQL API using SDK